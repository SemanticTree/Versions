function create_core_obj(container){
	var cy;
	if(container){
			cy=new cytoscape({
			container:document.getElementById(container_id)
		});
	}
	else{
		cy= new cytoscape();
	}
	return cy;
}

function LoadFile() {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
		    responseData=JSON.parse(this.responseText);
		    console.log(this.responseText);
			load_graph();
		};
	}
		xhttp.open("GET", "/juggad", true);
		xhttp.send();
}

function setLayout(lt, cy) {
	layout={name:lt};
	cy.layout(layout).run();
}

function logNodes(string="is_central") {
	cy.elements("node").forEach(function(ele){
		console.log(ele.data("title")+"    "+ele.data(string));
	});
}

function addStyle(level_limit) {
	// display_cy = create_core_obj(true);
	central=cy.elements("node[?is_central]")[0];
	dijkstra=cy.elements("*").dijkstra({
		"root": "node[?is_central]"
	});
	cy.nodes().forEach( function(ele) {
		if (this.distanceTo(ele) > level_limit){
			ele.style("visibility","hidden");
			ele.connectedEdges().style("visibility","hidden")
		}
	},dijkstra);
	cy.fit(cy.elements(":visible"), 10)
	// setLayout("cose-bilkent", cy);

}

function load_graph(){
	jsonObject=responseData;
  	cy.add(jsonObject['elements']);
  	cy.style(style);
  	setLayout("cose-bilkent", cy);
  	cy.nodes().ungrabify();
  	cy.nodes().style({"visibility":"visible"});
  	cy.edges().style({"visibility":"visible"});
  	addStyle(1000);
  	cy.nodes().on("tap",function(event){
		ele=event.target;
		cy.nodes().removeData("level");
		cy.nodes().data("is_central",false);
		cy.collection().add(ele).data("is_central",true);
		cy.elements().style({
			"visibility":"visible"
		});
		ele.unselect();
		addStyle(5);
	});
}

var container_id="cy";
var cy, display_cy;
var style=[
	{
		"selector":"node",
		"style":{
			"label":"data(title)",
			"text-valign":"center",
			'text-rotation':'autorotate',
			'height':'label',
			'width':'label',
			'padding':'10px'
		}
	},
	{
	  	"selector":"edge",
	  	"style":{
	  		// "label":"data(title)",
			'curve-style':'bezier',
			'target-arrow-color':'#ccc',
			'target-arrow-shape':'triangle',
			// 'text-margin-y':'-10px',
			// 'text-margin-x':'10px',
			'text-rotation':'autorotate'
		}
	}];
var levelled_style=[{

}];
var level_limit=1000;
var responseData;
from flask import Flask, request, render_template
import main
import json


app = Flask(__name__)
pff = None


@app.route('/')
def x():
    return ""


@app.route('/input_page')
def input_page():
    return render_template('new-input.html')


@app.route('/get_cytoscape_json_for_text', methods=['POST', 'GET'])
def get_cytoscape_json_for_text():
    global pff
    if request.method == "POST":
        text_to_process = request.form["input-text"]
        pff = json.dumps(main.generate_structured_data_from_text(text_to_process))
        return render_template('new-output.html')


@app.route('/juggad')
def juggad():
    global pff
    return pff


if __name__ == '__main__':
    app.run(debug=True)

# MD-TPM -> Module Dependency to be cleared at time of module (Text Processing Module) integration.

# Imports
import numpy as np
import re
import scipy.cluster.vq as cluster_v
from itertools import islice, combinations
from collections import defaultdict, deque, OrderedDict
from collections import namedtuple
from pprint import pprint as print_
import spacy
from spacy.tokens import Token
import warnings

connection = namedtuple('connection', 'node weight')
Index = namedtuple('Index', 'pid, sid, wid')

nlp = spacy.load('en', disable=['ner'])
# spacy.load('en_vectors_web_lg', vocab=nlp.vocab)
warnings.filterwarnings("ignore")

# Global Variables
THRESHOLD = 0.7  # MD-TPM
TREE = None  # Final Tree Object
ROOT = None  # Final root of Tree
DOC = None  # Actual doc object for the function
SENT_RANGE = None
WORD_RANGE = None


# Indexing of Tokens to a private system.
def set_index():
    """No-param function. Sets index <custom variable> for each token.
    Uses named tuple "Index" of the format(pid, sid, wid)
    Each successive paragraph, sentence, word recieves an incrementing ID

    Returns: None

    Note:
    Sets Global Variable <SENT_RANGE, WORD_RANGE, DOC>
    """
    global SENT_RANGE, WORD_RANGE, DOC
    SENT_RANGE = len(list(DOC.sents))
    WORD_RANGE = len(list(DOC))
    spacy.tokens.Token.set_extension('index', default=None, force=True)
    pc, sc, wc = 0, 0, 0
    for t in DOC:
        if t.text is '\n':
            pc += 1
        if t.is_sent_start:
            sc += 1
        if not t.is_punct and t.text is not '\n':
            t._.index = Index(pc, sc, wc)
            wc += 1


#  Frequency Counts and Instance List and unique tokens
def set_extentions():
    """No-param function. Sets 'frequency' and 'instance_list' variable for each token.
    The frequency is calculated by root.lemma_.lower() word of the noun phrase.
    And lemma_.lower() of root is used to add instance to instance list.

    Returns: None

    Note:
    Requires Global Variable <DOC>
    """

    global DOC
    freq_count = defaultdict(int)
    instance_list = defaultdict(list)
    for t in DOC.noun_chunks:
        freq_count[t.root.lemma_.lower()] += 1
        instance_list[t.root.lemma_.lower()].append(t)

    def get_freq(t):
        return freq_count[t.lemma_.lower()]

    def get_instance_list(t):
        return instance_list[t.lemma_.lower()]

    Token.set_extension('frequency', getter=get_freq, force=True)
    Token.set_extension('instance_list', getter=get_instance_list, force=True)


def make_unique(tokens):
    uniq = OrderedDict()
    for t in tokens:
        uniq.setdefault(t.root.lemma_.lower(), t)
    return list(uniq.values())

# Vector Functions
# Euclidean Distance Function


def euclidean_distance(x: np.ndarray, y: np.ndarray):
    """
    Calculate Euclidean distance of power 2

    Keyword Arguments:
    x -- First vector of dimension n
    y -- Second vector of dimension n
    """
    return np.linalg.norm(x - y)


# Similarity between vectors
def cosine_similarity(x: np.ndarray, y: np.ndarray):
    """
    Calculates Cosine Similarity : cos = A.B / |A||B|
    Answer value ranges from -1(Perfectly Opposite) to 1(perfectly Similar).
    Value of 0 translates to no similarity.

    Keyword Arguments:
    x -- First Vector of dimension n
    y -- Second Vector of dimension n
    """
    x_val, y_val = x.copy(), y.copy()
    assert x_val.shape == y_val.shape
    mod_x = (x_val ** 2).sum() ** 0.5
    mod_y = (y_val ** 2).sum() ** 0.5
    cos = x.dot(y) / (mod_x * mod_y)
    assert cos is not np.nan
    return cos


# Structural Distance Functions
# Paragraph Distance
# Implementing Static Calculation through : e^(-4x)
# Later versions may include dynamic calculations of z-score by getting all pairs of p_distance to produce more subtle(smooth) values. : a = (x-mean)/ std; z-score = scipy.stats.norm.cdf(a)


# v1.3 New Distance Function ::
def term_distance(term_a, term_b):
    """Calculates Term Distance using word sub-index by the formula : e^(x/r)
    r = word_range / sent_range
    """
    global DOC, SENT_RANGE, WORD_RANGE

    def min_dist_between_two_set(a, b):
        i, j = 0, 0
        min_diff = 100
        while i < len(a) and j < len(b):
            if min_diff > abs(a[i] - b[j]):
                x, y, min_diff = i, j, abs(a[i] - b[j])
            i, j = (i + 1, j) if a[i] < b[j] else (i, j + 1)
        return min_diff

    assert term_a.root._.instance_list is not []
    assert term_b.root._.instance_list is not []

    ax = [x.root._.index.wid for x in term_a.root._.instance_list]
    bx = [x.root._.index.wid for x in term_b.root._.instance_list]
    min_dist = min_dist_between_two_set(ax, bx)
    value = np.e ** -(min_dist * SENT_RANGE / WORD_RANGE)
    return value


# Frequency Sum MD-TMP 1.1
def freq_sum(a, b):
    """Get frequency Sum of the tokens a and b

    Keywords:
    a - 1st token object
    b - 2nd token object
    """
    summation = a.root._.frequency + b.root._.frequency
    return summation


# Generalised Sliding window function
def _sliding_window(iterable, size=2, step=1, fillvalue=None):
    """Sliding window over an iterable. Returns numpy array generator"""
    if size < 0 or step < 1:
        raise ValueError
    it = iter(iterable)
    q = deque(islice(it, size), maxlen=size)
    if not q:
        return
    q.extend(fillvalue for _ in range(size - len(q)))
    while True:
        yield list(q)
        try:
            q.append(next(it))
        except StopIteration:
            return
        q.extend(next(it, fillvalue) for _ in range(step - 1))


def make_sliding_pairs(arr, **kwargs):
    """Pair of tokens based on sliding window.

    Keywords:
    arr -- Iterable
    size(default=2) -- length of window
    step(default=1) -- skip after each window
    *fillvalue(default=None) -- Padding value
    """
    x = set()
    for a in _sliding_window(arr, **kwargs):
        x.update({c for c in combinations(a, 2) if None not in c})
    return x


# Compilation Functions
# Assign values - Compilation Functin - Key Pipeline Function
def assign_values(concept_list, weight_matrix=None, sliding_size=10):
    """
    Returns edge and value pair : ((node1, node2), edge_weight)

    Keyword:
    concept_list -  a list of unique concepts objects with properties: vector, p_id, s_id, w_id
    weight_matrix - weights for the various attributes.
    """
    global FREQ_COUNTS
    FREQ_COUNTS = None
    gathered_value = []

    edge_list = make_sliding_pairs(concept_list, size=sliding_size)

    vector_list = np.array([t.root.vector for t in concept_list])
    print(f'Total edges created     : {len(edge_list)}')

    for a, b in edge_list:
        cs = cosine_similarity(a.root.vector, b.root.vector)

        # Make a better fuction to get i values in future versions
        wd = term_distance(a, b)

        fs = freq_sum(a, b)
        arr = np.array([cs, wd, fs])
        gathered_value.append(arr)

    compiled = np.array(gathered_value)
    nrm = (compiled - compiled.min(axis=0)) / compiled.ptp(axis=0)

    w_mat = np.ones(3) / 3 if weight_matrix is None else weight_matrix
    w_normalised = nrm * w_mat

    total_nrm = w_normalised.sum(axis=1)

    pair = list(zip(edge_list, total_nrm))
    return pair


# Make thresholded graph
def make_graph(edge_list, threshold=0.0, max_connections=10):
    """Return 2 way graph from edge_list based on threshold"""
    graph = defaultdict(list)
    edge_list.sort(reverse=True, key=lambda x: x[1])
    for nodes, weight in edge_list:
        a, b = nodes
        if weight > threshold:
            if len(graph[a]) < max_connections:
                graph[a].append(connection(b, weight))
            if len(graph[b]) < max_connections:
                graph[b].append(connection(a, weight))
    print(f'Total graph nodes       : {len(graph.keys())}')
    print(f'Total graph connections : {sum(map(len, graph.values()))}')
    return graph


# Tree Generation Algorithm - Key Pipeline Function
def make_tree(graph):
    """
    Prepares a tree object from a graph based on edge strength. Determines the central node on its own.

    Keyword:
    graph -- A graph object(dict) containing list of connections as its value. E.g.
    { sapcy.token:node : [connection(node={spacy.token:node1}, weight={float:value}),..], ... }
    """
    tree = defaultdict(list)
    available = set(graph.keys())
    active = set()
    leaves = set()

    def _make_edge(parent, child, weight):
        child.set_extension('edge_strength', default=None, force=True)
        child._.edge_strength = weight
        child.set_extension('relation_to_parent', default=None, force=True)
        child._.relation_to_parent = get_relation(parent, child)[1]
        tree[parent].append(child)

    def get_max_from_available():
        return max(available, key=lambda x: x.root._.frequency)

    def get_max_from_active():
        return max(active, key=lambda x: graph[x][0].weight)

    root = get_max_from_available()
    available.remove(root)
    active.add(root)
    while(available):

        parent = get_max_from_active() if active else get_max_from_available()
        active.discard(parent)

        if not graph[parent]:
            leaves.add(parent)
            available.remove(parent)
            continue

        child, weight = graph[parent].pop(0)

        if child in available or child in leaves:  # danger
            _make_edge(parent, child, weight)
            available.remove(child)

            if graph[child]:
                active.add(child)

        if graph[parent]:
            active.add(parent)

    return tree, root


def get_relation(token1, token2):
    (lrg, sml) = ((token1, token2) if token1.start > token2.start else (token2, token1))
    output = [(token1, DOC[i], token2) for i in range(sml.end, lrg.start) if DOC[i].pos_ == "VERB"]
    if not output:
        output = (token1, 'has', token2)
    else:
        rels = [x[1] for x in output]
        rel2 = [x for x in rels if x.text not in ["is", "has", "have", "had", "was", "will"]]
        output = (token1, rels[int(len(rels) / 2)].text, token2)
    return output

# Dict object to Standard Dict - Key Pipeline Function


def make_a_node_dict(node):
    global TREE, ROOT
    node_dict = {}
    node_dict["title"] = node.text
    node_dict["i"] = node.sent.start_char  # MD-TPM 5.0
    node_dict["j"] = node.sent.end_char    # MD-TPM 5.0
    node_dict["relation_to_parent"] = node._.relation_to_parent  # MD-TPM 6.0
    node_dict["relation_strength"] = node._.edge_strength
    node_dict['is_central'] = node.text == ROOT.text
    node_dict["children"] = [ele for ele in map(make_a_node_dict, TREE[node])]
    return node_dict


# Transform StandardDict form to cytoscape form - Key Pipeline Function
def _transform_data(data: dict):
    """Accepts a data dictionary of standard format {Heirarchial format} and returns a
    format suitable for cytoscape.js"""
    new_dict = {'elements': []}
    elements = new_dict['elements']
    children, title = 'children', 'title'
    # r_st, rtp = 'relation_strength', 'relation_to_parent'

    def get_id():
        i = 1
        while True:
            yield 'edge' + str(i)
            i += 1

    id_generator = get_id()

    def add_node(node):
        elements.append({
            'data': {
                'id': node[title],
                'title': node[title],
                'has_child': node[children] == [],
                'i': node["i"],
                'j': node["j"],
                'is_central': node['is_central'],
            }
        })
        if node[children]:
            for a in node[children]:
                add_node(a)

        return

    def add_edge(node, parent):
        if node['relation_to_parent'] is not '-':
            if parent is not '-':
                elements.append({
                    'data': {
                        'id': next(id_generator),
                        'source': parent,
                        'target': node[title],
                        'title': node['relation_to_parent'],
                        'weight': node['relation_strength'],
                    }
                })
        if node[children]:
            for a in node[children]:
                add_edge(a, node[title])

        return

    new_dict = {'elements': []}
    elements = new_dict['elements']
    id_generator = get_id()
    add_node(data)
    add_edge(data, '-')
    return new_dict


def generate_structured_data_from_text(text):
    """Returns cytoscape compatible json structure"""

    global DOC, TREE, ROOT, SENT_RANGE, WORD_RANGE
    text = re.sub('(\\n)+', '\\n', text)  # remove consecutive newline
    # more text cleaning for unknown and wikipedia text

    # Anaphora Resolutions

    #
    DOC = nlp(text)

    set_index()
    set_extentions()

    tokens = list(DOC.noun_chunks)
    concept_list = make_unique(tokens)  # unique tokens
    for c in concept_list:
        print("%-15s %-15s %s" % (c.root.lemma_.lower(), c.text, c.root._.instance_list))

    x = np.array([0.45, 0.4, 0.15])  # cs, wd, fr

    # Skip from here for Module Integration
    a = assign_values(concept_list, weight_matrix=x, sliding_size=15)
    g = make_graph(a, threshold=0.5, max_connections=7)
    TREE, ROOT = make_tree(g)

    print(f'Root Node               : {ROOT}')
    print("Final Tree Created      :\n" + "*" * 40)

    standard_dict = make_a_node_dict(ROOT)
    cytoscape_dict = _transform_data(standard_dict)
    return cytoscape_dict


if __name__ == "__main__":
    sample_text = """
    An essay is, generally, a piece of writing that gives the author's own argument — but the definition is vague, overlapping with those of a paper, an article, a pamphlet, and a short story. Essays have traditionally been sub-classified as formal and informal. Formal essays are characterized by "serious purpose, dignity, logical organization, length," whereas the informal essay is characterized by "the personal element (self-revelation, individual tastes and experiences, confidential manner), humor, graceful style, rambling structure, unconventionality or novelty of theme," etc.[1]

    Essays are commonly used as literary criticism, political manifestos, learned arguments, observations of daily life, recollections, and reflections of the author. Almost all modern essays are written in prose, but works in verse have been dubbed essays (e.g., Alexander Pope's An Essay on Criticism and An Essay on Man). While brevity usually defines an essay, voluminous works like John Locke's An Essay Concerning Human Understanding and Thomas Malthus's An Essay on the Principle of Population are counterexamples.

    In some countries (e.g., the United States and Canada), essays have become a major part of formal education. Secondary students are taught structured essay formats to improve their writing skills; admission essays are often used by universities in selecting applicants, and in the humanities and social sciences essays are often used as a way of assessing the performance of students during final exams.

    The concept of an "essay" has been extended to other media beyond writing. A film essay is a movie that often incorporates documentary filmmaking styles and focuses more on the evolution of a theme or idea. A photographic essay covers a topic with a linked series of photographs that may have accompanying text or captions.
    """

    print_(generate_structured_data_from_text(sample_text))

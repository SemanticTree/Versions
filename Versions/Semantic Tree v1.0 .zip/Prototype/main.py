# MD-TPM -> Module Dependency to be cleared at time of module (Text Processing Module) integration.

# Imports
import numpy as np
import scipy.cluster.vq as cluster_v
from itertools import islice, combinations
from collections import defaultdict, deque
from collections import namedtuple
from pprint import pprint as print_
import spacy
import warnings

connection = namedtuple('connection', 'node weight')

nlp = spacy.load('en', disable=['ner'])
# spacy.load('en_vectors_web_lg', vocab=nlp.vocab)
warnings.filterwarnings("ignore")

# Global Variables
THRESHOLD = 0.7  # MD-TPM
TREE = None  # Final Tree Object
ROOT = None  # Final root of Tree
FREQ_COUNTS = None  # MD-TPM 1.0
DOC = None  # Actual doc object for the function


# Initiaion Code


# Temporary Frequency Function - MD-TMP 1.2
def set_freq_variable():
    # setting freq for each variable
    global DOC, FREQ_COUNTS

    FREQ_COUNTS = DOC.count_by(spacy.attrs.ORTH)

    def get_freq(token): return FREQ_COUNTS[token.orth]

    for t in DOC:
        t.set_extension('freq', getter=get_freq, force=True)


PARA_RANGE = 10    # MD-TPM 2.0
SENT_RANGE = 100   # MD-TPM 2.1
WORD_RANGE = 1000  # MD-TPM 2.2

CONCEPT_POS = ['ADJ', 'NOUN', 'PROPN']  # MD-TMP 3.0


# Vector Functions
# Euclidean Distance Function
def euclidean_distance(x: np.ndarray, y: np.ndarray):
    """
    Calculate Euclidean distance of power 2

    Keyword Arguments:
    x -- First vector of dimension n
    y -- Second vector of dimension n
    """
    return np.linalg.norm(x - y)


# Similarity between vectors
def cosine_similarity(x: np.ndarray, y: np.ndarray):
    """
    Calculates Cosine Similarity : cos = A.B / |A||B|
    Answer value ranges from -1(Perfectly Opposite) to 1(perfectly Similar).
    Value of 0 translates to no similarity.

    Keyword Arguments:
    x -- First Vector of dimension n
    y -- Second Vector of dimension n
    """
    x_val, y_val = x.copy(), y.copy()
    assert x_val.shape == y_val.shape
    mod_x = (x_val ** 2).sum() ** 0.5
    mod_y = (y_val ** 2).sum() ** 0.5
    cos = x.dot(y) / (mod_x * mod_y)
    assert cos is not np.nan
    return cos


# Structural Distance Functions
# Paragraph Distance
# Implementing Static Calculation through : e^(-4x)
# Later versions may include dynamic calculations of z-score by getting all pairs of p_distance to produce more subtle(smooth) values. : a = (x-mean)/ std; z-score = scipy.stats.norm.cdf(a)

# Paragraph Distance MD-TMP 2.0.1
def paragraph_distance(x: int, y: int):
    """
    Calculates static paragraph distance value based on equation: e^(-4x).

    Keyword Argument:
    x -- First paragraph value within range PARA_RANGE for first term.
    y -- Second Paragraph value within range PARA_RANGE for second term.

    Note:
    The function requires global variable PARA_RANGE.
    PARA_RANGE is the maximum difference between paragraph index i.e to be calculated / set beforehand.
    """
    global PARA_RANGE
    assert isinstance(x, int)
    assert isinstance(y, int)
    diff = abs(x - y)
    norm = diff / PARA_RANGE
    p_value = np.e ** (-4 * norm)
    return p_value


# Sentence Distance MD-TMP 2.1.1
def sentence_distance(x: int, y: int):
    """
    Calculates static sentence distance value based on equation: e^(-4x).

    Keyword Argument:
    x -- First sentence value within range SENT_RANGE for first term.
    y -- Second sentence value within range SENT_RANGE for second term.

    Note:
    The function requires global variable SENT_RANGE.
    SENT_RANGE is the maximum difference between sentence index i.e. to be calculated / set beforehand.
    """
    global SENT_RANGE
    assert isinstance(x, int)
    assert isinstance(y, int)
    diff = abs(x - y)
    norm = diff / SENT_RANGE
    s_value = np.e ** (-4 * norm)
    return s_value


# Word Distance MD-TMP 2.2.1
def word_distance(x: int, y: int):
    """
    Calculates static word distance value based on equation: e^(-4x).

    Keyword Arguments:
    x -- First word value within range WORD_RANGE for first term.
    y -- Second word value within range WORD_RANGE for second term.

    Note:
    The function requires global variable WORD_RANGE.
    WORD_RANGE is the maximum difference between word index i.e. to be calculated / set beforehand.
    """
    global WORD_RANGE
    assert isinstance(x, int)
    assert isinstance(x, int)
    diff = abs(x - y)
    norm = diff / WORD_RANGE
    w_value = np.e ** (-4 * norm)
    return w_value


# Frequency Sum MD-TMP 1.1
def freq_sum(a: spacy.tokens.token.Token, b: spacy.tokens.token.Token):
    """Get frequency Sum of the tokens a and b

    Keywords:
    a - 1st token object
    b - 2nd token object
    """
    global FREQ_COUNTS
    if FREQ_COUNTS is None:
        set_freq_variable()  # MD-TMP 1.2
    summation = a._.freq + b._.freq
    return summation


# Generalised Sliding window function
def _sliding_window(iterable, size=2, step=1, fillvalue=None):
    """Sliding window over an iterable. Returns numpy array generator"""
    if size < 0 or step < 1:
        raise ValueError
    it = iter(iterable)
    q = deque(islice(it, size), maxlen=size)
    if not q:
        return
    q.extend(fillvalue for _ in range(size - len(q)))
    while True:
        yield list(q)
        try:
            q.append(next(it))
        except StopIteration:
            return
        q.extend(next(it, fillvalue) for _ in range(step - 1))


def make_sliding_pairs(arr, **kwargs):
    """Pair of tokens based on sliding window.

    Keywords:
    arr -- Iterable
    size(default=2) -- length of window
    step(default=1) -- skip after each window
    *fillvalue(default=None) -- Padding value
    """
    x = set()
    for a in _sliding_window(arr, **kwargs):
        x.update({c for c in combinations(a, 2) if None not in c})
    return x


# Compilation Functions
# Assign values - Compilation Functin - Key Pipeline Function
def assign_values(concept_list, weight_matrix=None):
    """
    Returns edge and value pair : ((node1, node2), edge_weight)

    Keyword:
    concept_list -  a list of unique concepts objects with properties: vector, p_id, s_id, w_id
    weight_matrix - weights for the various attributes.
    """
    global FREQ_COUNTS
    FREQ_COUNTS = None
    gathered_value = []

    # edge_list = list(combinations(concept_list, 2))
    edge_list = make_sliding_pairs(concept_list, size=100)

    vector_list = np.array([t.vector for t in concept_list])
    print(f'Total edges created     : {len(edge_list)}')

    for a, b in edge_list:
        cs = cosine_similarity(a.vector, b.vector)

        # Make a better fuction to get i values in future versions
        index_val = a.i, b.i  # MD-TPM 4.0
        wd = word_distance(*index_val)

        fs = freq_sum(a, b)
        arr = np.array([cs, wd, fs])
        gathered_value.append(arr)

    compiled = np.array(gathered_value)
    nrm = (compiled - compiled.min(axis=0)) / compiled.ptp(axis=0)

    w_mat = np.ones(3) / 3 if weight_matrix is None else weight_matrix
    w_normalised = nrm * w_mat

    total_nrm = w_normalised.sum(axis=1)

    pair = list(zip(edge_list, total_nrm))
    return pair


# Make thresholded graph
def make_graph(edge_list, threshold=0.0, max_connections=10):
    """Return 2 way graph from edge_list based on threshold"""
    graph = defaultdict(list)
    edge_list.sort(reverse=True, key=lambda x: x[1])
    for nodes, weight in edge_list:
        a, b = nodes
        if weight > threshold:
            if len(graph[a]) < max_connections:
                graph[a].append(connection(b, weight))
            if len(graph[b]) < max_connections:
                graph[b].append(connection(a, weight))
    print(f'Total graph nodes       : {len(graph.keys())}')
    print(f'Total graph connections : {sum(map(len, graph.values()))}')
    return graph


# Tree Generation Algorithm - Key Pipeline Function
def make_tree(graph):
    """
    Prepares a tree object from a graph based on edge strength. Determines the central node on its own.

    Keyword:
    graph -- A graph object(dict) containing list of connections as its value. E.g.
    { sapcy.token:node : [connection(node={spacy.token:node1}, weight={float:value}),..], ... }
    """
    tree = defaultdict(list)
    available = set(graph.keys())
    active = set()
    leaves = set()

    def _make_edge(parent, child, weight):
        child.set_extension('edge_strength', default=None, force=True)
        child._.edge_strength = weight
        tree[parent].append(child)

    def get_max_from_available():
        return max(available, key=lambda x: x._.freq)

    def get_max_from_active():
        return max(active, key=lambda x: graph[x][0].weight)

    root = get_max_from_available()
    available.remove(root)
    active.add(root)
    while(available):

        parent = get_max_from_active() if active else get_max_from_available()
        active.discard(parent)

        if not graph[parent]:
            leaves.add(parent)
            available.remove(parent)
            continue

        child, weight = graph[parent].pop(0)

        if child in available or child in leaves:  # danger
            _make_edge(parent, child, weight)
            available.remove(child)

            if graph[child]:
                active.add(child)

        if graph[parent]:
            active.add(parent)

    return tree, root


# Dict object to Standard Dict - Key Pipeline Function
def make_a_node_dict(node):
    global TREE, ROOT
    node_dict = {}
    node_dict["title"] = node.text
    node_dict["i"] = node.sent.start_char  # MD-TPM 5.0
    node_dict["j"] = node.sent.end_char    # MD-TPM 5.0
    node_dict["relation_to_parent"] = 'undefined'  # MD-TPM 6.0
    node_dict["relation_strength"] = node._.edge_strength
    node_dict['is_central'] = node.text == ROOT.text
    node_dict["children"] = [ele for ele in map(make_a_node_dict, TREE[node])]
    return node_dict


# Transform StandardDict form to cytoscape form - Key Pipeline Function
def _transform_data(data: dict):
    """Accepts a data dictionary of standard format {Heirarchial format} and returns a
    format suitable for cytoscape.js"""
    new_dict = {'elements': []}
    elements = new_dict['elements']
    children, title = 'children', 'title'
    r_st, rtp = 'relation_strength', 'relation_to_parent'

    def get_id():
        i = 1
        while True:
            yield 'edge' + str(i)
            i += 1

    id_generator = get_id()

    def add_node(node):
        elements.append({
            'data': {
                'id': node[title],
                'title': node[title],
                'has_child': node[children] == [],
                'i': node["i"],
                'j': node["j"],
                'is_central': node['is_central'],
            }
        })
        if node[children]:
            for a in node[children]:
                add_node(a)

        return

    def add_edge(node, parent):
        if node[rtp] is not '-':
            if parent is not '-':
                elements.append({
                    'data': {
                        'id': next(id_generator),
                        'source': parent,
                        'target': node[title],
                        'title': node[rtp],
                        'weight': node[r_st]
                    }
                })
        if node[children]:
            for a in node[children]:
                add_edge(a, node[title])

        return

    new_dict = {'elements': []}
    elements = new_dict['elements']
    id_generator = get_id()
    add_node(data)
    add_edge(data, '-')
    return new_dict


def generate_structured_data_from_text(text):
    """Returns cytoscape compatible json structure"""
    global DOC, TREE, ROOT
    DOC = nlp(text)
    tokens = list(DOC)
    raw = [t for t in tokens
           if not t.is_punct
           and not t.is_stop
           and t.pos_ in CONCEPT_POS
           and t.has_vector]
    raw = list(dict((obj.norm, obj) for obj in raw).values())  # make unique
    concept_list = raw.copy()

    x = np.array([0.4, 0.25, 0.35])

    # Skip from here for Module Integration
    a = assign_values(concept_list, weight_matrix=x)
    g = make_graph(a, threshold=0.5, max_connections=10)
    TREE, ROOT = make_tree(g)

    print(f'Root Node               : {max(raw, key=lambda x:x._.freq)}')
    print("Final Tree Created      :\n" + "*" * 40)

    standard_dict = make_a_node_dict(ROOT)
    cytoscape_dict = _transform_data(standard_dict)
    return cytoscape_dict


if __name__ == "__main__":
    sample_text = """
    An essay is, generally, a piece of writing that gives the author's own argument — but the definition is vague, overlapping with those of a paper, an article, a pamphlet, and a short story. Essays have traditionally been sub-classified as formal and informal. Formal essays are characterized by "serious purpose, dignity, logical organization, length," whereas the informal essay is characterized by "the personal element (self-revelation, individual tastes and experiences, confidential manner), humor, graceful style, rambling structure, unconventionality or novelty of theme," etc.[1]

    Essays are commonly used as literary criticism, political manifestos, learned arguments, observations of daily life, recollections, and reflections of the author. Almost all modern essays are written in prose, but works in verse have been dubbed essays (e.g., Alexander Pope's An Essay on Criticism and An Essay on Man). While brevity usually defines an essay, voluminous works like John Locke's An Essay Concerning Human Understanding and Thomas Malthus's An Essay on the Principle of Population are counterexamples.

    In some countries (e.g., the United States and Canada), essays have become a major part of formal education. Secondary students are taught structured essay formats to improve their writing skills; admission essays are often used by universities in selecting applicants, and in the humanities and social sciences essays are often used as a way of assessing the performance of students during final exams.

    The concept of an "essay" has been extended to other media beyond writing. A film essay is a movie that often incorporates documentary filmmaking styles and focuses more on the evolution of a theme or idea. A photographic essay covers a topic with a linked series of photographs that may have accompanying text or captions.
    """

    print_(generate_structured_data_from_text(sample_text))
